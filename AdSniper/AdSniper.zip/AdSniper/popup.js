document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.local.get(['adsBlocked'], function (result) {
        const count = result.adsBlocked || 0;
        document.getElementById('count').textContent = count;
    });
});
