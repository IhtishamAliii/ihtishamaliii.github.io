let adsBlocked = 0;

// Initialize from storage on startup
chrome.storage.local.get(['adsBlocked'], function(result) {
    if (result.adsBlocked) {
        adsBlocked = result.adsBlocked;
    }
});

function updateStorage() {
    try {
        // Check if the extension context is valid before updating storage
        if (chrome && chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({ adsBlocked }, () => {
                if (chrome.runtime.lastError) {
                    console.error("Storage update failed:", chrome.runtime.lastError);
                } else {
                    // console.log("Storage updated successfully");
                }
            });
        } else {
            console.error("Extension context invalidated: Unable to update storage");
        }
    } catch (error) {
        console.error("Error updating storage:", error);
    }
}

// Ensure storage operations are wrapped in try-catch
function removeAdElements() {
    try {
        const adSelectors = [
            // Video player ad elements
            '.ytp-ad-module',
            '.ytp-ad-overlay-container',
            '.ytp-ad-overlay-slot',
            '.ytp-ad-progress',
            '.ytp-ad-progress-list',
            '.ytp-ad-text-overlay',
            
            // Page ad elements
            '.ytd-banner-promo-renderer',
            '.ytd-display-ad-renderer',
            '.ytd-companion-slot-renderer',
            '.ytd-promoted-sparkles-web-renderer',
            '.ytd-merch-shelf-renderer',
            '.ytd-carousel-ad-renderer',
            '.ytd-promoted-video-renderer',
            '.ytd-masthead-ad-renderer',
            '.ytd-in-feed-ad-layout-renderer',
            '.ytd-banner-promo-renderer',
            '.ytd-statement-banner-renderer',
            '.ytd-ad-slot-renderer'
        ];

        let removedAds = 0;
        adSelectors.forEach(selector => {
            try {
                const elements = document.querySelectorAll(selector);
                elements.forEach(el => {
                    if (el && el.parentNode) {
                        el.remove();
                        removedAds++;
                        // console.log(`[Removed ad element]: ${selector}`);
                    }
                });
            } catch (selectorError) {
                console.error(`Error processing selector ${selector}:`, selectorError);
            }
        });

        if (removedAds > 0) {
            adsBlocked += removedAds;
            updateStorage();
        }

        return removedAds;
    } catch (error) {
        console.error("Error in removeAdElements:", error);
        return 0;
    }
}

function isAdPlaying() {
    try {
        // Multiple methods to detect ads
        const methods = [
            // Traditional ad-showing class
            () => !!document.querySelector('.ad-showing'),
            // Video ads can be detected through ad overlays
            () => !!document.querySelector('.ytp-ad-player-overlay'),
            // Check for text on skip button container even if button isn't there yet
            () => !!document.querySelector('.ytp-ad-skip-button-container'),
            // Check for ad text in the player
            () => !!document.querySelector('.ytp-ad-text')
        ];

        // Return true if any method detects an ad
        return methods.some(method => {
            try {
                return method();
            } catch (e) {
                return false;
            }
        });
    } catch (error) {
        console.error("Error checking if ad is playing:", error);
        return false;
    }
}

function handleUnskippableAd(video) {
    try {
        const mainVideo = document.getElementsByClassName('video-stream html5-main-video')[0];
        if (mainVideo && isFinite(mainVideo.duration) && mainVideo.duration > 0) {
            console.log("[!] Attempting to skip unskippable ad...");
            mainVideo.currentTime = mainVideo.duration;
            adsBlocked++;
            updateStorage();
            return true;
        }
        
        // Fallback to original methods if specific selector fails
        if (video && isFinite(video.duration) && video.duration > 0) {
            console.log("[✓] Handling unskippable ad with direct video targeting");
            video.currentTime = video.duration;
            adsBlocked++;
            updateStorage();
            return true;
        }
        
        return false;
    } catch (error) {
        console.error("Error handling unskippable ad:", error);
        return false;
    }
}

function skipAdIfPossible() {
    try {
        // Try to find skip button
        const skipButtons = [
            '.ytp-ad-skip-button',
            '.ytp-ad-skip-button-modern',
            '.videoAdUiSkipButton'
        ];
        
        for (const buttonSelector of skipButtons) {
            const skipBtn = document.querySelector(buttonSelector);
            if (skipBtn) {
                // console.log(`[✓] Found skip button: ${buttonSelector}`);
                skipBtn.click();
                adsBlocked++;
                updateStorage();
                return true;
            }
        }
        
        // If no skip button found, try handling as unskippable
        if (isAdPlaying()) {
            return handleUnskippableAd();
        }
        
        return false;
    } catch (error) {
        console.error("Error in skipAdIfPossible:", error);
        return false;
    }
}

function removeAdElements() {
    try {
        const adSelectors = [
            // Video player ad elements
            '.ytp-ad-module',
            '.ytp-ad-overlay-container',
            '.ytp-ad-overlay-slot',
            '.ytp-ad-progress',
            '.ytp-ad-progress-list',
            '.ytp-ad-text-overlay',
            
            // Page ad elements
            '.ytd-banner-promo-renderer',
            '.ytd-display-ad-renderer',
            '.ytd-companion-slot-renderer',
            '.ytd-promoted-sparkles-web-renderer',
            '.ytd-merch-shelf-renderer',
            '.ytd-carousel-ad-renderer',
            '.ytd-promoted-video-renderer',
            '.ytd-masthead-ad-renderer',
            '.ytd-in-feed-ad-layout-renderer',
            '.ytd-banner-promo-renderer',
            '.ytd-statement-banner-renderer',
            '.ytd-ad-slot-renderer'
        ];

        let removedAds = 0;
        adSelectors.forEach(selector => {
            try {
                const elements = document.querySelectorAll(selector);
                elements.forEach(el => {
                    if (el && el.parentNode) {
                        el.remove();
                        removedAds++;
                        // console.log(`[Removed ad element]: ${selector}`);
                    }
                });
            } catch (selectorError) {
                console.error(`Error processing selector ${selector}:`, selectorError);
            }
        });

        if (removedAds > 0) {
            adsBlocked += removedAds;
            updateStorage();
        }

        return removedAds;
    } catch (error) {
        console.error("Error in removeAdElements:", error);
        return 0;
    }
}

function monitorAds() {
    try {
        // Handle ad detection and removal
        if (isAdPlaying()) {
            skipAdIfPossible();
        }
        
        // Remove banner/overlay ads
        removeAdElements();
        
    } catch (error) {
        console.error("Error in monitorAds:", error);
    }
}

// Use a mutation observer to detect changes
let adObserver;
function setupAdObserver() {
    try {
        if (adObserver) {
            adObserver.disconnect();
        }
        
        adObserver = new MutationObserver((mutations) => {
            if (isAdPlaying()) {
                monitorAds();
            }
        });
        
        // Watch for DOM changes that might indicate ads
        const targetNode = document.querySelector('body');
        if (targetNode) {
            adObserver.observe(targetNode, { 
                childList: true, 
                subtree: true, 
                attributes: true, 
                attributeFilter: ['class'] 
            });
        }
        
        // Also specifically watch the player area
        const playerArea = document.querySelector('#movie_player');
        if (playerArea) {
            adObserver.observe(playerArea, {
                attributes: true,
                childList: true,
                subtree: true
            });
        }
    } catch (error) {
        console.error("Error setting up observer:", error);
    }
}

// Initial setup
function initialize() {
    try {
        // Run initial scan
        monitorAds();
        
        // Set up observers
        setupAdObserver();
        
        // Check for ads periodically
        setInterval(monitorAds, 1000);
        
        // Re-establish observers if page changes significantly
        setInterval(setupAdObserver, 30000);
        
        // console.log("[Ad Blocker] Successfully initialized");
    } catch (error) {
        console.error("Error during initialization:", error);
    }
}

// Check if we're in a YouTube page
if (window.location.hostname.includes('youtube.com')) {
    // Wait for the page to load properly
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }
    
    // Also run on history state changes (for single-page app navigation)
    window.addEventListener('yt-navigate-finish', function() {
        setTimeout(initialize, 1000);
    });
}