// Instagram Grid Downloader - Content Script
(function() {
  // SVG Icons
  const icons = {
    download: `<svg viewBox="0 0 24 24"><path d="M12 16l-6-6h4V4h4v6h4l-6 6zm-8 4h16v2H4v-2z"/></svg>`,
    copy: `<svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>`,
    check: `<svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>`
  };

  // Toast notification
  function showToast(message) {
    let toast = document.querySelector('.ig-ext-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'ig-ext-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2000);
  }

  // Download image function
  async function downloadImage(url, filename) {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(blobUrl);
      showToast('Image downloaded!');
      return true;
    } catch (e) {
      window.open(url, '_blank');
      showToast('Opened in new tab');
      return false;
    }
  }

  // Copy to clipboard function
  async function copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (e) {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      return true;
    }
  }

  // Button click feedback
  function showSuccess(btn) {
    const origHTML = btn.innerHTML;
    btn.innerHTML = icons.check;
    btn.classList.add('success');
    setTimeout(() => {
      btn.innerHTML = origHTML;
      btn.classList.remove('success');
    }, 1500);
  }

  // Create button element
  function createButton(icon, title, onClick) {
    const btn = document.createElement('button');
    btn.className = 'ig-ext-btn';
    btn.innerHTML = icon;
    btn.title = title;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick(btn);
    });
    return btn;
  }

  // Add buttons to posts
  function addButtonsToPost(post, index) {
    if (post.querySelector('.ig-ext-btn-container')) return;

    const img = post.querySelector('img');
    const href = post.getAttribute('href');
    if (!img || !img.src) return;

    const container = post.querySelector('._aagu');
    if (container) container.style.position = 'relative';

    const btnContainer = document.createElement('div');
    btnContainer.className = 'ig-ext-btn-container';

    // Download button
    const dlBtn = createButton(icons.download, 'Download image', async (btn) => {
      const filename = `instagram-${Date.now()}.jpg`;
      const success = await downloadImage(img.src, filename);
      if (success) showSuccess(btn);
    });

    // Copy link button
    const copyBtn = createButton(icons.copy, 'Copy post link', async (btn) => {
      const fullUrl = href.startsWith('http') ? href : `https://www.instagram.com${href}`;
      await copyToClipboard(fullUrl);
      showToast('Link copied!');
      showSuccess(btn);
    });

    btnContainer.appendChild(dlBtn);
    btnContainer.appendChild(copyBtn);

    if (container) {
      container.appendChild(btnContainer);
    } else {
      post.style.position = 'relative';
      post.appendChild(btnContainer);
    }
  }

  // Process all posts
  function processAllPosts() {
    const posts = document.querySelectorAll('a._a6hd');
    posts.forEach((post, i) => addButtonsToPost(post, i));
  }

  // Initialize
  processAllPosts();

  // Watch for new posts
  const observer = new MutationObserver(() => {
    processAllPosts();
  });
  observer.observe(document.body, { childList: true, subtree: true });

  console.log('Instagram Grid Downloader loaded!');
})();